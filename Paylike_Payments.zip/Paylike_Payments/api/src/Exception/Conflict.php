<?php

namespace Paylike\Exception;

/**
 * Class Conflict
 *
 * @package Paylike\Exception
 */
class Conflict extends ApiException
{

}
